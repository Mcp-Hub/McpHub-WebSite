#!/bin/bash
python runtime/updateids.py "$@"
